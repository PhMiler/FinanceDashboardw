<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

/**
 * Middleware responsável por proteger a aplicação contra ataques CSRF
 * (Cross-Site Request Forgery) em formulários e requisições.
 */
class VerifyCsrfToken extends Middleware
{
    /**
     * Rotas que devem ser excluídas da verificação CSRF.
     *
     * @var array<int, string>
     */
    protected $except = [
        // Adicione URIs a serem ignoradas pela proteção CSRF, se necessário
    ];
}
