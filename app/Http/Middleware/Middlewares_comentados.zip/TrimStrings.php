<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\TrimStrings as Middleware;

/**
 * Middleware responsável por remover espaços em branco
 * do início e do fim de todas as strings recebidas nas requisições.
 */
class TrimStrings extends Middleware
{
    /**
     * Os nomes dos atributos que não devem ser "trimados".
     *
     * @var array<int, string>
     */
    protected $except = [
        // 'password', 'password_confirmation'
    ];
}
