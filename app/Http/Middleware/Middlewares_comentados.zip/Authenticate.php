<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

/**
 * Middleware responsável por garantir que o usuário esteja autenticado
 * para acessar rotas protegidas do sistema.
 */
class Authenticate extends Middleware
{
    /**
     * Redireciona o usuário não autenticado para a página de login.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string|null
     */
    protected function redirectTo($request)
    {
        // Se o usuário não está autenticado, redireciona para a rota 'login'
        if (! $request->expectsJson()) {
            return route('login');
        }
    }
}
