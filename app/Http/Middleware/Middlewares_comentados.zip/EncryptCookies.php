<?php

namespace App\Http\Middleware;

use Illuminate\Cookie\Middleware\EncryptCookies as Middleware;

/**
 * Middleware responsável por criptografar automaticamente todos os cookies
 * definidos pelo aplicativo e descriptografar os cookies recebidos.
 */
class EncryptCookies extends Middleware
{
    /**
     * Os nomes dos cookies que não devem ser criptografados.
     *
     * @var array<int, string>
     */
    protected $except = [
        // Adicione aqui os cookies que NÃO devem ser criptografados (caso necessário)
    ];
}
