<?php

namespace App\Http\Middleware;

use Illuminate\Http\Middleware\TrustProxies as Middleware;
use Illuminate\Http\Request;

/**
 * Middleware responsável por configurar proxies confiáveis
 * (ex: load balancers, serviços de proxy reverso) para o Laravel.
 */
class TrustProxies extends Middleware
{
    /**
     * Os endereços IP dos proxies confiáveis.
     *
     * @var array<int, string>|string|null
     */
    protected $proxies;

    /**
     * Os cabeçalhos que devem ser usados para detectar informações do proxy.
     *
     * @var int
     */
    protected $headers = Request::HEADER_X_FORWARDED_ALL;
}
