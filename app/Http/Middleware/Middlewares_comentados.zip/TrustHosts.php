<?php

namespace App\Http\Middleware;

use Illuminate\Http\Middleware\TrustHosts as Middleware;

/**
 * Middleware responsável por definir os hosts confiáveis para a aplicação.
 * Ajuda a proteger contra ataques de host header poisoning.
 */
class TrustHosts extends Middleware
{
    /**
     * Retorna a lista de padrões de hosts confiáveis.
     *
     * @return array<int, string|null>
     */
    public function hosts()
    {
        return [
            $this->allSubdomainsOfApplicationUrl(),
            // Adicione outros hosts confiáveis, se necessário
        ];
    }
}
