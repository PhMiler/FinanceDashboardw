<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\PreventRequestsDuringMaintenance as Middleware;

/**
 * Middleware que bloqueia requisições quando a aplicação está em modo manutenção.
 * Exibe uma página informando que o sistema está indisponível temporariamente.
 */
class PreventRequestsDuringMaintenance extends Middleware
{
    /**
     * Lista de IPs autorizados a acessar o sistema mesmo durante a manutenção.
     *
     * @var array<int, string>
     */
    protected $except = [
        // Adicione aqui IPs que terão acesso liberado durante a manutenção
    ];
}
