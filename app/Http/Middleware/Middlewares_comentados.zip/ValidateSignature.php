<?php

namespace App\Http\Middleware;

use Illuminate\Routing\Middleware\ValidateSignature as Middleware;

/**
 * Middleware que garante que as URLs assinadas (signed URLs) sejam válidas e não tenham sido alteradas.
 * Usado para proteger rotas sensíveis como redefinição de senha e confirmações por e-mail.
 */
class ValidateSignature extends Middleware
{
    /**
     * Nomes de parâmetros de query string que devem ser ignorados na validação.
     *
     * @var array<int, string>
     */
    protected $except = [
        // Adicione parâmetros que não devem ser validados, se necessário
    ];
}
